<?php declare(strict_types = 1);
namespace PharIo\Version;

class NoPreReleaseSuffixException extends \Exception implements Exception {
}
